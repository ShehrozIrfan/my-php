<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Super Globals</title>
</head>
<body>
    <form action="process.php" method="get">
        <div>
            <input type="text" name="username" placeholder="Enter Username">
        </div>
        <div>
            <input type="number" name="age" placeholder="Enter Age">
        </div>
        <div>
           <!-- creating a url and then we will access the value using php in another file. -->
            <a href="process.php?value= <?php echo '15'; ?>">Value</a>
        </div>
        <div>
            <input type="submit" name="submit" value="Submit">
        </div>
    </form>
</body>
</html>