<?php 

echo "<pre>";
print_r($_GET);
echo "</pre>";

echo "<br>";

echo $_GET['value'];

?>