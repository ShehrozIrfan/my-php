<?php

//if(isset($_POST['submit'])) {
//    echo "It works ... !";
//}



#extracting data from form
//
//if(isset($_POST['submit'])) {
//    $username = $_POST['username'];
//    $password = $_POST['password'];
//    
//    echo "Hello " . $username . "<br>" . "Your password is : " . $password;
//}


#validating the form
//
//if(isset($_POST['submit'])) {
//    $username = $_POST['username'];
//    $password = $_POST['password'];
//    
//    $min = 8;
//    $max = 20;
//    
//    if(strlen($password) < $min) {
//        echo "<br>" .  "Password must be greater than $min";
//    }
//    if(strlen($password) > $max) {
//        echo "<br>" . "Password must be less than or equal to " . $max;
//    }
//    
//    $names = ['Asad', 'Nouman', 'Ubaid', 'Qasim', 'Shehroz'];
//    
//    if(in_array($username, $names)) {
//        echo "Welcome";
//    } else {
//        echo "Sorry, you're not allowed to Login ... !";
//    }
//}


/*  



Step1: Make a form that submits one value to POST super global


 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forms</title>
</head>
<body>
    <form action="form_process.php" method="post">
        <input type="text" name="username" placeholder="Enter username">
        <br/><br/>
        <input type="password" name="password" placeholder="Enter password">
        <br/><br/>
        <button type="submit" name="submit">Submit</button>
    </form>
</body>
</html>