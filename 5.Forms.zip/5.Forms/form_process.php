<?php
//External File

if(isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $min = 8;
    $max = 20;
    
    if(strlen($password) < $min) {
        echo "<br>" .  "Password must be greater than $min";
    }
    if(strlen($password) > $max) {
        echo "<br>" . "Password must be less than or equal to " . $max;
    }
    
    $names = ['Asad', 'Nouman', 'Ubaid', 'Qasim', 'Shehroz'];
    
    if(in_array($username, $names)) {
        echo "Welcome";
    } else {
        echo "<br>" . "Sorry, you're not allowed to Login ... !";
    }
}

?>