<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Verification</title>
    <!-- adding bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-sm-12 col-md-6">
                <div class="alert alert-warning">Please verify your email</div>
                <p class="m-2 text-center">We've sent you a 7 digit verification code on your entered email.</p>
                <div class="m-2">
                    <form action="process.php" method="post">
                        <div class="form-group">
                            <input type="number" name="code" placeholder="Enter 7 digit code" class="form-control">
                        </div>
                        <div class="form-group">
                            <button class="btn btn-warning btn-sm mt-2" name="verify">Verify</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>