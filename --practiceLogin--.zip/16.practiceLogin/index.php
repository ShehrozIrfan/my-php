<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign up</title>
    <!-- adding bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-sm-12 col-md-6">
                <form action="process.php" method="post">
                    <div class="form-group">
                        <input type="email" placeholder="Enter email" name="email" class="form-control m-2">
                    </div>
                    <div class="form-group">
                        <input type="password" placeholder="Enter password" name="password" class="form-control m-2">
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary btn-sm m-2" name="signup">Sign Up</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>