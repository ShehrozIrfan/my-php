<?php 

//establishing connection

$connection = mysqli_connect('localhost', 'root', 'root', 'practice_sign_up', '3307');

if(!$connection) {
    die("Database Connection Failed." . mysqli_error($connection));
}

?>