<?php include "db_connection.php" ?>

<?php 

$msg = '';
$msgClass = '';

if(isset($_POST['signup'])) {
    //getting user data
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    //saving the username in a temporary file.
    $fEmail = "temEmail.txt";
    $fPassword = "temPassword.txt";
    
    $handleEmail = fopen($fEmail, 'w');
    $handlePassword = fopen($fPassword, 'w');
    if($handleEmail && $handlePassword) {
        fwrite($handleEmail, $email);
        fwrite($handlePassword, $password);
        
        fclose($handleEmail);
        fclose($handlePassword);
    }
    
    //generating a random number
    $random = rand(2744639, 9967221);
    
    //inserting the random number into the database.
    $query = "INSERT INTO verify(code) ";
    $query .= "VALUES('$random')";
    
    $result = mysqli_query($connection, $query);
    
    if(!$result) {
        die("Insertion Query Failed!" . mysqli_error($connection));
    }
    
    //sending email to user.
    $toEmail = $email;
    
    $subject = "Verification Email from --- Website";
    
    $body = "
    <h2>Your Verification code is: </h2>
    <h1>$random</h1>
    ";
    
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html; charset=UTF-8" . "\r\n";
    
    $headers .= "From: --Shehroz Irfan--" . "<shehrozirfan89@gmail.com>";
    
    if(mail($toEmail, $subject, $body, $headers)) {
        //email sent successfully.
        
        header("location: verify.php");
        
        
    } else {
        $msg = "Sending Verification Email Failed.";
        $msgClass = "alert-danger";
    }
}

if(isset($_POST['verify'])) {
    //getting the user entered code.
    $code = $_POST['code'];
    
    
    //getting the code from database.
    $query = "SELECT * FROM verify";
    
    $result = mysqli_query($connection, $query);
    
    if(!$result) {
        die("Query Failed!" . mysqli_error($connection));
    } else {
        $row = mysqli_fetch_assoc($result);
        
        $codeDb = $row['code'];
        
        if($code == $codeDb) {
            //verification successful
            //1. truncate the verify table.
            
            $query = "TRUNCATE TABLE verify";
            
            $result = mysqli_query($connection, $query);
            
            if(!$result) {
                die("Truncation table failed!" . mysqli_error($connection));
            } else {
                //2. inserting the user details in the database.
                
                $fEmail = "temEmail.txt";
                $fPassword = "temPassword.txt";
                
                $handleEmail = fopen($fEmail, 'r');
                $handlePassword = fopen($fPassword, 'r');
                
                global $email;
                global $password;
                
                if($handleEmail && $handlePassword) {
                    $email = fread($handleEmail, filesize($fEmail));
                    
                    $password = fread($handlePassword, filesize($fPassword));
                    
                    unlink("temEmail.txt");
                    unlink("temPassword.txt");
                }
                
                $query = "INSERT INTO users(email, password) ";
                $query .= "VALUES('$email','$password')";
                
                $result = mysqli_query($connection, $query);
                
                if(!$result) {
                    echo "Inserting user data query failed!" . mysqli_error($connection);
                } else {
                    //3. taking the user to main dashboard.
                    
                    header("location: welcome.php");
                }
            }
            
            
        } else {
//            $msg = "Invalid Code - Verification Failed.";
//            
//            $msgClass = "alert-danger";
            
            echo('<script>alert("Invalid Code - Verification Failed!");</script>');
            
            $query = "TRUNCATE TABLE verify";
            
            $result = mysqli_query($connection, $query);
            
            if(!$result) {
                die("Truncation table failed!" . mysqli_error($connection));
            }
            
            header("location: index.php");
            
        }
        
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Verification</title>
    <!-- adding bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-sm-12 col-md-6">
                <div>
                    <?php if($msg != '') { ?>
                    <div class="alert <?php echo $msgClass ?>">
                        
                        <?php echo $msg ?>
                        
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>


