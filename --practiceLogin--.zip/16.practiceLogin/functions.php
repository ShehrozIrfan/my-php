<?php 

global $value;

if(isset($_POST['submit'])) {
    
    $value = $_POST['value'];
}
echo $value . "Value";


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <form action="functions.php" method="post">
        <input type="text" name="value">
        <input type="submit" name="submit">
        
    </form>
    
    <form action="functions.php" method="post">
        <input type="submit" name="verify" value="Verify">
    </form>
</body>
</html>