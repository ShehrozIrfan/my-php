<?php

$msg = '';
$msgClass = '';

if(isset($_POST['submit'])) {
    //getting the values.
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];
    
    
    $toEmail = "shehrozirfan89@gmail.com";
    
    $subject = "Contact request from " . $name;
    
    $body = "
    <h2>Contact Request</h2>
    <h4>Name</h4>
    <p>$name</p>
    <h4>Email</h4>
    <p>$email</p>
    <h4>Message</h4>
    <p>$message</p>
    ";
    
    //Email headers
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type:text/html;charset=UTF-8" . "\r\n";
    
    //Additional headers
    $headers .= "From: " . $name . "<" . $email . ">" . "\r\n";
    
    
    //checking
    if(mail($toEmail, $subject, $body, $headers)) {
        //Email sent
        $msg = "Your email has been sent!";
        $msgClass = "alert-success";
    } else {
        //failed.
        $msg = "Sending email failed!";
        $msgClass = "alert-danger";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sending the Email</title>
    <!-- adding bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-sm-12 col-md-6">
               <?php if($msg != '') { ?>
               
               <div class="alert <?php echo $msgClass ?>">
                   
                   <?php echo $msg ?>
                   
               </div>
               
               <?php } ?>
                <form action="index.php" method="post">
                    <div class="form-group">
                        <input type="text" name="name" placeholder="Enter name" class="form-control mt-2" required>
                    </div>
                    <div class="form-group">
                        <input type="email" name="email" placeholder="Enter email" class="form-control mt-2" required>
                    </div>
                    <div class="form-group">
                        <textarea name="message" cols="30" rows="5" class="form-control mt-2" placeholder="Add your comment..." required></textarea>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary mt-2" name="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>